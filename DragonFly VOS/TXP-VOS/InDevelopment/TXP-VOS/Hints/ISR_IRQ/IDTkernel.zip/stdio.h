#ifndef STDIO
#define STDIO


void clear_screen(); //clears the screen, duh
void print(char *msg, unsigned int line);//prints a message to the screen at line specified

#endif // stdio.h
